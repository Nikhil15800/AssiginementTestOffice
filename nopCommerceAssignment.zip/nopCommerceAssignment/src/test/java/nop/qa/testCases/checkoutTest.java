package nop.qa.testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import nop.qa.base.TestBase;
import nop.qa.pages.*;
public class checkoutTest extends TestBase{
	TestBase TB = new TestBase();
	checkoutPage checkoutPage = new checkoutPage();
	
	
//	@BeforeClass
//	public void setup() {
//		TB.initialization();
//	}
//	
//	
//	@Test(priority=1)
//	public void agreeTermTest() {
//		checkoutPage.agreeTermPage();
//	}
//	
//	@Test(priority=2)
//	public void checkoutPageTest() {
//		checkoutPage.checkoutPaymentPage();
//	}
	
	@Test(priority=1)
	public void detailsCheckoutTest() {
		checkoutPage.detailsCheckoutPage();
	}
	
	@Test(priority=2)
	public void countryStateTest() {
		checkoutPage.countryStatePage();
	}
	
	@Test(priority=3)
	public void addressTest() {
		checkoutPage.addressPage();
	}
	

	
	@Test(priority=4)
	public void shppingMethodTest() {
		checkoutPage.shppingMethodPage();
	}
	
	@Test(priority=5)
	public void paymentTest() {
		checkoutPage.paymentPage();
	}
	
	@Test(priority=6)
	public void cardTypeTest() {
		checkoutPage.cardTypePage();
	}
	
	@Test(priority=7)
	public void CardholdernameTest() {
		checkoutPage.CardholdernamePage();
	}
	
	@Test(priority=8)
	public void CardnumberTest() {
		checkoutPage.CardnumberPage();
	}
	
	@Test(priority=9)
	public void CardnumberPageTest() {
		checkoutPage.CardnumberPage();
	}
	
	
	@Test(priority=10)
	public void ExpirationdateTest() {
		checkoutPage.ExpirationdatePage();
	}
	
	@Test(priority=11)
	public void CardcodeTest() {
		checkoutPage.CardcodePage();
	}
	
	@Test(priority=12)
	public void contniueBtnTest() {
		checkoutPage.contniueBtnPage();
	}
	
	
	@Test(priority=13)
	public void confirmOrderTest() {
		checkoutPage.confirmOrderPage();
	}
	
	@Test(priority=14)
	public void successfullTest() {
		checkoutPage.successfullPage();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
