package nop.qa.testCases;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import nop.qa.pages.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import nop.qa.base.TestBase;

public class loginTest extends TestBase{
	loginPage loginPage = new loginPage();
	TestBase TB = new TestBase();
	
	
	public loginTest() {
		super();
	} 
	
	
	@Test(priority=1)
	public void logintextTest() {
		loginPage.logintextPage();
	}
	
	@Test(priority=2)
	public void emailTest() {
		loginPage.emailPage();
	}
	
	@Test(priority=3)
	public void passwordTest() {
		loginPage.passwordPage();
	}
	
	@Test(priority=4)
	public void remindTest() {
		loginPage.remindPage();
	}
	
	@Test(priority=5)
	public void  loginBtnTest() {
		loginPage.loginBtnPage();
	}
	
	@Test(priority=6)
	public void agreeTermTest() {
		loginPage.agreeTermPage();
	}
	
	@Test(priority=7)
	public void checkoutPaymentTest() {
		loginPage.checkoutPaymentPage();
	}
	
}
