package nop.qa.testCases;
import nop.qa.pages.*;
//import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import nop.qa.base.TestBase;

public class categoryTest extends TestBase{
	categoryPage categoryPage = new categoryPage();
	TestBase TB = new TestBase();
	
	
	public categoryTest() {
		super();
	} 
	// TestBase initialization() method call : 
	
	@BeforeClass
	public void setup() {
		TB.initialization();
	}
	
	@Test(priority=1)
	public void computerTest() {
		categoryPage.computerPage();
	}
	
	@Test(priority=2)
	public void desktopTest() {
		categoryPage.desktopPage();
	}
	
	@Test(priority=3)
	public void buildComputerTest() {
		categoryPage.buildComputerPage();
	}
	

}
