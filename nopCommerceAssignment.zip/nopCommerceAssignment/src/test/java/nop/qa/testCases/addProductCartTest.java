package nop.qa.testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import nop.qa.pages.*;
import nop.qa.base.TestBase;

public class addProductCartTest extends TestBase{
	TestBase TB = new TestBase();
	addProductCartPage addProductCartPage = new addProductCartPage();
	public addProductCartTest() {
		super();
	} 
	// TestBase initialization() method call : 
	
	@BeforeClass
	public void setup() {
		TB.initialization();
	}
	@Test(priority=1)
	public void urlTest() {
		addProductCartPage.urlopen();
	}
	@Test(priority=2)
	public void processorTest() {
		addProductCartPage.processorPage();
	}
	
	@Test(priority=3)
	public void ramTest() {
		addProductCartPage.ramPage();
	}
	@Test(priority=4)
	public void hddTest() {
		addProductCartPage.hddPage();
	}
	
	@Test(priority=5)
	public void OsTest() {
		addProductCartPage.OsPage();
	}
	
	@Test(priority=6)
	public void softwareTest() {
		addProductCartPage.softwarePage();
	}
	
	@Test(priority=7)
	public void addToCartTest() {
		addProductCartPage.addToCartPage();
	}
	@Test(priority=8)
	public void sleepTest() {
		try {
		    Thread.sleep(5000);             
		    } catch(InterruptedException ex) {
		    Thread.currentThread().interrupt();
		}
	}
	
	@Test(priority=9)
	public void shoppingCartTest() {
		addProductCartPage.shoppingCartPage();
	}
	

}
