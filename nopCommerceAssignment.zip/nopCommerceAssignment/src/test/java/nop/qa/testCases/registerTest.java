package nop.qa.testCases;

//import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import nop.qa.base.TestBase;
import nop.qa.pages.registerPage;

public class registerTest extends TestBase{
	registerPage registerPage = new registerPage();
	TestBase TB = new TestBase();
	
	
	public registerTest() {
		super();
	} 
	// TestBase initialization() method call : 
	
	@BeforeClass
	public void setup() {
		TB.initialization();
	}
	
	
	@Test(priority=1)
	public void RegisterBtnTest() {
		registerPage.validateRegisterBtn();
	}
	
	@Test(priority=2)
	public void RegGenderTest() {
		registerPage.validateRegGender();
	}
	
	@Test(priority=3)
	public void RegNameTest() {
		registerPage.validateRegName();
	}
	
	
	@Test(priority=4)
	public void RegDOBTest() {
		registerPage.validateDateOfBirth();
	}
	
	@Test(priority=5)
	public void RegEailTest() {
		registerPage.validateEmail();
	}
	
	@Test(priority=6)
	public void RegcompanyNameTest() {
		registerPage.validatecompanyName();
	}
	
	@Test(priority=7)
	public void RegNewsletterTest() {
		registerPage.validateNewsletter();
	}
	
	@Test(priority=8)
	public void RegPasswoedTest() {
		registerPage.validatePassword();
	}
	
	@Test(priority=9)
	public void RegRegisterBtnClickTest() {
		registerPage.validateRegisterBtnClick();
	}
	@Test(priority=10)
	public void RegContinueTest() {
		registerPage.validateContinue();
	}
	
//	@AfterClass
//	public void tearDown() {
//		driver.quit();
//	}
	
}
