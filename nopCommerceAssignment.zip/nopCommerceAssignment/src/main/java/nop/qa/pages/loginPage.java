package nop.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import nop.qa.base.TestBase;

public class loginPage extends TestBase {
	
	public void logintextPage() {
		WebElement login = driver.findElement(By.xpath("//a[@class='ico-login']"));
		login.click();
	}
	
	public void emailPage() {
		WebElement email = driver.findElement(By.xpath("//input[@id='Email']"));
		email.sendKeys(prop.getProperty("email"));
	}
	
	public void passwordPage() {
		WebElement password = driver.findElement(By.xpath("//input[@id='Password']"));
		password.sendKeys(prop.getProperty("password"));
	}
	
	public void remindPage() {
		WebElement remindme = driver.findElement(By.xpath("//input[@id='RememberMe']"));
		remindme.click();
	}
	
	public void loginBtnPage() {
		WebElement logbtn = driver.findElement(By.xpath("//button[@class='button-1 login-button']"));
		logbtn.click();
	}
	
//  Navigate to the checkout page : 
	public void agreeTermPage() {
		WebElement term = driver.findElement(By.xpath("//input[@id='termsofservice']"));
		term.click();
	}
	
	public void checkoutPaymentPage() {
		WebElement checkout = driver.findElement(By.xpath("//button[@class='button-1 checkout-button']"));
		checkout.click();
	}

}
