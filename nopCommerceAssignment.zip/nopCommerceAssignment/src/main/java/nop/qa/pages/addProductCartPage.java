package nop.qa.pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import nop.qa.base.TestBase;

public class addProductCartPage extends TestBase{
	public static Select select;
//	public void urlopen() {
////		driver.get("https://demo.nopcommerce.com/build-your-own-computer");
//	}
	
	public void computerPage() {
		driver.findElement(By.xpath("//a[@href='/computers']//parent::li")).click();
	}
	
	public void desktopPage() {
		driver.findElement(By.xpath("//a[@href='/desktops']//parent::h2")).click();
	}
	
	public void buildComputerPage() {
		driver.findElement(By.xpath("//a[@href='/build-your-own-computer' and text()='Build your own computer']")).click();
	}
	
	
	public void processorPage() {
		WebElement processor = driver.findElement(By.xpath("//select[@id='product_attribute_1']"));
		select = new Select(processor);
		List<WebElement> alloptions = select.getOptions();
		for (WebElement option : alloptions) {
			if(option.getText().equals("2.2 GHz Intel Pentium Dual-Core E2200")) {
				option.click();
				break;
			}
		}
	}
	
	public void ramPage() {
		WebElement ram = driver.findElement(By.xpath("//select[@id='product_attribute_2']"));
		select = new Select(ram);
		select.selectByValue("5");
   
	}
	public void hddPage() {
		WebElement hdd = driver.findElement(By.xpath("//input[@id='product_attribute_3_7']"));
		hdd.click();
	}
	
	public void OsPage() {
		WebElement os = driver.findElement(By.xpath("//input[@id='product_attribute_4_9']"));
		os.click();
	}
	
	public void softwarePage() {
		WebElement software = driver.findElement(By.xpath("//input[@id='product_attribute_5_12']"));
		software.click();
	}
	
	public void addToCartPage() {
		WebElement addToCart = driver.findElement(By.xpath("//button[@class='button-1 add-to-cart-button']"));
		addToCart.click();
		
	}

	public void shoppingCartPage() {
		WebElement shoppingCart = driver.findElement(By.xpath("//span[@class='cart-label']"));
		shoppingCart.click();
	}
	
	
//  Navigate to the checkout page : 
	public void agreeTermPage() {
		WebElement term = driver.findElement(By.xpath("//input[@id='termsofservice']"));
		term.click();
	}
	
	public void checkoutPaymentPage() {
		WebElement checkout = driver.findElement(By.xpath("//button[@class='button-1 checkout-button']"));
		checkout.click();
	}

}
