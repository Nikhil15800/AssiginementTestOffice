package nop.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import nop.qa.base.TestBase;

public class checkoutPage extends TestBase{
	
	
//	
//	public void agreeTermPage() {
//		WebElement term = driver.findElement(By.xpath("//input[@id='termsofservice']"));
//		term.click();
//	}
//	
//	public void checkoutPaymentPage() {
//		WebElement checkout = driver.findElement(By.xpath("//button[@class='button-1 checkout-button']"));
//		checkout.click();
//	}
	
	// Ship to the same address : 
	
	public void detailsCheckoutPage() {
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_FirstName']")).sendKeys("Nikhil");
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_LastName']")).sendKeys("Khandelwal");
		
		// E-mail : 
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_Email']")).clear();
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_Email']")).sendKeys("nikhil555.khandelwal@gmail.com");
		
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_Company']")).sendKeys("Sarvika Technologies Pvt Ltd");
		
		
	}
	
	// Country and State 
	
	public void countryStatePage() {
		WebElement country= driver.findElement(By.xpath("//select[@id='BillingNewAddress_CountryId']"));
		Select select = new Select(country);
		select.selectByValue("133");
//		
//		WebElement state= driver.findElement(By.xpath("//select[@id='BillingNewAddress_StateProvinceId']"));
//		Select select1 = new Select(state);
//		select1.selectByValue("0");
		
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_City']")).sendKeys("Jaipur");
		
	}
	
	public void addressPage() {
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_Address1']")).sendKeys("GopalPura jaipur");
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_Address2']")).sendKeys("GopalPura jaipur");
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_ZipPostalCode']")).sendKeys("302031");
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_PhoneNumber']")).sendKeys("0123456789");
		driver.findElement(By.xpath("//input[@id='BillingNewAddress_FaxNumber']")).sendKeys("012345");
		
		// Continue btn : 
		driver.findElement(By.xpath("//button[@class='button-1 new-address-next-step-button' and @name='save']")).click();
		
		
	}
	
	
	// Shipping method  : 
	public void shppingMethodPage(){
		
		
//		driver.switchTo().alert().accept();
		
//		Robot robot = new Robot();
//		robot.mouseMove(400, 400);
//		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		
		driver.findElement(By.xpath("//button[@onclick='ShippingMethod.save()']")).click();	
	}
	
	
	
	
	// Do the payment 
	
	public void paymentPage() {
		driver.findElement(By.xpath("//input[@id='paymentmethod_1']")).click();
		driver.findElement(By.xpath("//button[@class='button-1 payment-method-next-step-button']")).click();
	}
	
	
	
	
	// Payment information : 
	public void cardTypePage() {
		WebElement cardType = driver.findElement(By.xpath("//select[@class='dropdownlists']"));
		Select select = new Select(cardType);
		select.selectByValue("visa");
	}
	
	
	public void CardholdernamePage() {
		WebElement cardHolderName = driver.findElement(By.xpath("//input[@id='CardholderName']"));
		cardHolderName.sendKeys("sarah Pandi");
	}
	
	public void CardnumberPage() {
		driver.findElement(By.xpath("//input[@id='CardNumber']")).sendKeys("4689431650955500");
	}
	
	public void ExpirationdatePage() {
		WebElement day = driver.findElement(By.xpath("//select[@id='ExpireMonth']"));
		Select select = new Select(day);
		select.selectByValue("1");
		
		WebElement year = driver.findElement(By.xpath("//select[@id='ExpireYear']"));
		Select select1 = new Select(year);
		select1.selectByValue("2023");
		
	}
	
	public void CardcodePage() {
		driver.findElement(By.xpath("//input[@id='CardCode']")).sendKeys("111");
	}
	
	public void contniueBtnPage() {
		driver.findElement(By.xpath("button-1 payment-info-next-step-button")).click();
	}
	
	
	// Confirm order : 
	
	public void confirmOrderPage() {
		driver.findElement(By.xpath("//button[@class='button-1 confirm-order-next-step-button']")).click();
	}
	
	
	// Your order has been successfully processed!
	
	public void successfullPage() {
		driver.findElement(By.xpath("//button[@class='button-1 order-completed-continue-button']")).click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
