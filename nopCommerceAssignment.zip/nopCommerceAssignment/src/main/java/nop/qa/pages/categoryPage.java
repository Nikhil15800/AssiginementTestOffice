package nop.qa.pages;

import org.openqa.selenium.By;

import nop.qa.base.TestBase;
import org.openqa.selenium.WebElement;

public class categoryPage extends TestBase{

	
	public void computerPage() {
		driver.findElement(By.xpath("//a[@href='/computers']//parent::li")).click();
	}
	
	public void desktopPage() {
		driver.findElement(By.xpath("//a[@href='/desktops']//parent::h2")).click();
	}
	
	public void buildComputerPage() {
		WebElement buildComputer = driver.findElement(By.xpath("//a[@href='/build-your-own-computer']//parent::div"));
		buildComputer.click();
	}

}
