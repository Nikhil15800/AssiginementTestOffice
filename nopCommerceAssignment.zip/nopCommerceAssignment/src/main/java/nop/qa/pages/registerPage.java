package nop.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import nop.qa.base.TestBase;

public class registerPage extends TestBase {
	public static Select select;
//	loginPage loginPage = new loginPage();

	// Page factory & object repository

//	@FindBy(className = "ico-register")
//	WebElement registerBtn;
//
//	@FindBy(id = "gender-male")
//	WebElement gender;
//
//	@FindBy(id = "FirstName")
//	WebElement Fname;
//
//	@FindBy(id = "LastName")
//	WebElement Lname;
//
//	public registerPage() {
//		PageFactory.initElements(driver, this);
//	}

	public void validateRegisterBtn() {
		// Register click : 
				WebElement register = driver.findElement(By.className("ico-register"));
				register.click();
	}

	public void validateRegGender() {
		// Radio button click :
				WebElement radiobtn = driver.findElement(By.id("gender-male"));
				radiobtn.click();
	}

	public void validateRegName() {
		WebElement fname = driver.findElement(By.id("FirstName"));
		fname.sendKeys("Nikhil");

		WebElement lname = driver.findElement(By.id("LastName"));
		lname.sendKeys("Khandelwal");
	}

	public void validateDateOfBirth() {
		// Day :
				WebElement day = driver.findElement(By.xpath("//select[@name='DateOfBirthDay']"));
				Select select=new Select(day);
				List<WebElement> alloption = select.getOptions();
				for(WebElement option:alloption)
				{
					if (option.getText().equals("10")) {
						option.click();
						break;
					}
				}

		// Month :
		WebElement month = driver.findElement(By.name("DateOfBirthMonth"));
		select = new Select(month);
		List<WebElement> alloption1 = select.getOptions();
		for (WebElement option : alloption1) {
			if (option.getText().equals("December")) {
				option.click();
				break;
			}
		}

		// Year :
		WebElement year = driver.findElement(By.name("DateOfBirthYear"));
		select = new Select(year);
		List<WebElement> alloptions = select.getOptions();
		for (WebElement option : alloptions) {
			if (option.getText().equals("2000")) {
				option.click();
				break;
			}
		}
	}

	public void validateEmail() {
		// Email :
		WebElement email = driver.findElement(By.id("Email"));
		email.sendKeys(prop.getProperty("email"));
	}
	
	public void validatecompanyName() {
		// Company Name
				WebElement companyName = driver.findElement(By.xpath("//input[@id='Company' or @name='Company']"));
				companyName.sendKeys("Sarvika technologies Pvt Ltd.");
	}
	
	public void validateNewsletter() {
		// Options :
				WebElement options = driver.findElement(By.xpath("//input[@id='Newsletter' or @name='Newsletter']"));
				options.click();
	}
	
	public void validatePassword() {
		// password :
				WebElement pass = driver.findElement(By.xpath("//input[@type='password' or @id='Password']"));
				pass.sendKeys(prop.getProperty("password"));

				// Confirm password :
				WebElement Cpass = driver.findElement(By.xpath("//input[@id='ConfirmPassword']"));
				Cpass.sendKeys(prop.getProperty("password"));
	}

	// Register btn :
	public void validateRegisterBtnClick() {
		// Click Register btn :
				WebElement regBtn = driver.findElement(By.xpath("//button[@id='register-button' and @class='button-1 register-next-step-button']"));
				regBtn.click();
		
	}
	
//	public void validateContinue() {
//		driver.findElement(By.className("button-1 register-continue-button")).click();
//	}
//	

}
